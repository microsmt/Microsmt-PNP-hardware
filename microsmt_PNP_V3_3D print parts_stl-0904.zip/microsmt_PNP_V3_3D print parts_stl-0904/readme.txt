1: 0816  electric feeder's  STL files,Assembly instructions, firmware,     please download from   https://docs.mgrl.de/maschine:pickandplace:feeder:0816feeder

You can use the original 0816 feeder file or my modified feeder file. I just changed the motor of take off tape to N30 Worm drive to save space.  So I only provide download of take off tape files here.

2:  Stripe Feeder's  STL file, please download from   https://docs.mgrl.de/maschine:pickandplace:feeder:manualfeeders

3: You can also find them in the hardware web  of the openpnp official website.

4: For machines received after June 25, 2023, the solenoid valve has been installed on the top of the Z motor, so item 5 is not required. The top camera is installed under the Z motor. No longer installed on the left side.
