
1:   https://youtu.be/H-nkwTwpxRA            For easier understanding, Please follow this video for hardware installation and software debug.  We no longer provide paper installation guides.   
       
      microsmt_pnpboard_v1.7_manual-1214.pdf          You also need to read this document in order to correctly connect the cables.


 
2:  Stripe Feeder's  STL file, please download from   https://docs.mgrl.de/maschine:pickandplace:feeder:manualfeeders

3： PNPV3 mainly works with Bing feeders, and we do not recommend 0816 feeders because the stability of push-pull feeders is poor and they cannot support 0402.

