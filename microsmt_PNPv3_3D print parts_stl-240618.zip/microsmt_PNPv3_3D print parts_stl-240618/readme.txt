1: You can also find them in the hardware web  of the openpnp official website.

2:   https://youtu.be/H-nkwTwpxRA            Please follow this video for hardware installation and software debug.

3:  Stripe Feeder's  STL file, please download from   https://docs.mgrl.de/maschine:pickandplace:feeder:manualfeeders

4： PNPV3 mainly works with Bing feeders, and we do not recommend 0816 feeders because the stability of push-pull feeders is poor and they cannot support 0402

