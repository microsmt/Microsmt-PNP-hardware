1: 0816  electric feeder's  STL files,Assembly instructions, firmware,     please download from   https://docs.mgrl.de/maschine:pickandplace:feeder:0816feeder

2:  Stripe Feeder's  STL file,     please download from   https://docs.mgrl.de/maschine:pickandplace:feeder:manualfeeders

3: You can also find them in the hardware web  of the openpnp official website.
